package trainingcenter;

public class Trainer extends TrainingManagement {
	
	private String name;
	private int id;
	private double totalSalary;
	private double Recoveredsalary;
	private double RemainingSalary;
	
	Trainer(String name,int id,double totalSalary,double Recoveredsalary,double RemainingSalary)
	{
		this.name=name;
		this.id=id;
		this.totalSalary=totalSalary;
		this.Recoveredsalary=Recoveredsalary;
		this.RemainingSalary=RemainingSalary;
		Totalspendingoftrainingcenter+=Recoveredsalary;
		
	}
	
	public void displayTrainerDetails()
	{
		System.out.println("[After creating a trainer object who is paid an amount of 3000 Trainer");
		System.out.println("Tainer name="+name+ ", Tainer id="+id+ ", TotalSalary="+totalSalary+ ", Recoveredsalary="+ Recoveredsalary+ ", RemainingSalary="+RemainingSalary+"]");
		
	}
	

	

}
