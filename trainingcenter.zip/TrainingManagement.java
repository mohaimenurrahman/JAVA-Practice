package trainingcenter;

public class TrainingManagement {

	protected static double Totalearnoftrainingcenter=0.0;
	protected static double Totalspendingoftrainingcenter=0.0;
	protected static double Totalprofitoftrainingcenter=0.0;
	
	public void displayTrainingManagements()
	{
		System.out.println("Initial income, expenses and profits");
		System.out.println("Total earn of training center="+Totalearnoftrainingcenter);
		System.out.println("Total spending of training center="+Totalspendingoftrainingcenter);
		System.out.println("Total profit of training center="+Totalprofitoftrainingcenter);
		System.out.println("***************************************************************");
		
	} 
	
	
	public void displayTrainingManagement()
	{
		Totalprofitoftrainingcenter=Totalearnoftrainingcenter-Totalspendingoftrainingcenter;
		System.out.println("Total earn of training center="+Totalearnoftrainingcenter);
		System.out.println("Total spending of training center="+Totalspendingoftrainingcenter);
		System.out.println("Total profit of training center="+Totalprofitoftrainingcenter);
		System.out.println("***************************************************************");
		
	} 
	
	
}
