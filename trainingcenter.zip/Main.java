package trainingcenter;

public class Main {

	public static void main(String[] args) {
		TrainingManagement obj = new TrainingManagement();
		obj.displayTrainingManagements();
		Trainee obj1 = new Trainee("Akash",101,3000.0,5000.0,25000.0,4);
		obj1.displayTraineeDetails();
		obj1.displayTrainingManagement();
		Trainee obj2=new Trainee("Akash",101,30000.0,5000.0,25000.0,4);
		obj2.displayTraineeDetailss();
		obj2.displayTrainingManagement();
		Trainer obj3=new Trainer("Anis",501,40000,3000,37000);
		obj3.displayTrainerDetails();
		obj3.displayTrainingManagement();
		
		

	}

}
