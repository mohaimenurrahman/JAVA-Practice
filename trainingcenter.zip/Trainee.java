package trainingcenter;

public class Trainee extends TrainingManagement {
	private String name;
	private int id;
	private double TotalFees;
	private double PaidFees;
	private double RemainingFees;
	private int grade;
	
	Trainee(String name,int id,double TotalFees,double PaidFees,double RemainingFees,int grade)
	{
		this.name=name;
		this.id=id;
		this.TotalFees=TotalFees;
		this.PaidFees=PaidFees;
		this.RemainingFees=RemainingFees;
		this.grade=grade;
		Totalearnoftrainingcenter+=PaidFees;
		
	}
	
	public void displayTraineeDetails() 
	{   
		System.out.println("After creating one trainee object who pays 5000 amount of money Trainee");
		System.out.println("[Trainee name="+name+", Trainee id="+id+" , Trainee TotalFees="+TotalFees+", Trainee PaidFees="+PaidFees+", Trainee RemainingFees="+RemainingFees+", Trainee grade="+grade+"]");
		
	}
	
	public void displayTraineeDetailss() 
	{   
		System.out.println("After creating one trainee object who pays 6000 amount of money Trainee");
		System.out.println("[Trainee name="+name+", Trainee id="+id+" , Trainee TotalFees="+TotalFees+", Trainee PaidFees="+PaidFees+", Trainee RemainingFees="+RemainingFees+", Trainee grade="+grade+"]");
		
	}
	

}
