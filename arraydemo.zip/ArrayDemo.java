package arraydemo;

import java.util.Scanner;

public class ArrayDemo {

	public void arrayofage()
	{
		int arr[]=new int[5];
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<5;i++)
		{
			System.out.print("\nEnter age"+(i+1)+":");
			arr[i]=sc.nextInt();
		}
		System.out.print("\nEntered age:");
		for(int i=0;i<5;i++)
		{
			System.out.print(arr[i]+" ");
		}
		arr[2]=24;
		System.out.print("\nThe age after edit:");
		for(int i=0;i<5;i++)
		{
			System.out.print(arr[i]+" ");
		}
	}
	
	public void arrayofname()
	{
		String arr[]=new String[5];
		Scanner sc = new Scanner(System.in);
		for(int i=0;i<5;i++)
		{
			System.out.print("\nEnter name"+(i+1)+":");
			arr[i]=sc.next();
		}
		System.out.print("\nEntered name:");
		for(int i=0;i<5;i++)
		{
			System.out.print(arr[i]+" ");
		}
		
	}
	
	public void sum()
	{
		int value[]= {5,5,5,5,10,10,20,10};
		int sum=0;
		for(int i=0;i<value.length;i++)
		{
			sum+=value[i];
		}
		System.out.print("\nsum :"+sum);
	}
	
	
	public void arrayofcgpa()
	{
		double[][] array = new double[2][2];
		Scanner sc=new Scanner(System.in);
		System.out.print("\n Enter cgppa of student semester wise accordingly:");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.print("\n Enter cgpa of student"+(i+1)+" semester"+(j+1)+": ");
				array[i][j]=sc.nextDouble();
			}
		}
		System.out.print("\n cgpa matrix : \n");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.print(array[i][j]+ " ");
			}
			System.out.println();
		}
		
	}
	public void exercise()
		{
			String [][] array=new String [5][5];
			Scanner sc =new Scanner(System.in);
			System.out.print("\n Enter name of student semester wise accordingly");
			for(int i=0;i<5;i++)
			{
				for(int j=0;j<5;j++)
				{
					System.out.print("\n Enter name of student"+(i+1)+" semester"+(j+1)+": ");
					array[i][j]=sc.next();
				}
			}
			
			System.out.print("\nname matrix:\n");
			for(int i=0;i<5;i++)
			{
				for(int j=0;j<5;j++)
				{
					System.out.print(array[i][j]+" ");
				}
				System.out.println();
			}
			
		}	
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


