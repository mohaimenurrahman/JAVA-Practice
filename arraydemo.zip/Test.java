package arraydemo;

public class Test {

	public static void main(String[] args) {
		 ArrayDemo obj =new  ArrayDemo();
		 obj.arrayofage();
		 obj.arrayofname();
		 obj.sum();
		 obj.arrayofcgpa();
		 obj.exercise();
		

	}

}
