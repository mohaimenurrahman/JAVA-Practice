package week2Exercise;

public class Week2Main {

	
	public  Week2Main(String x)
	{
		System.out.println("GOOD MORNING "+x);
	}
    public Week2Main(String name , String id)
    {
    	System.out.println("My name is " +name+ " and my id is "+id);
    }
	
	 public static void  sum(int x, int y)
	{   
		int s=x+y;
		System.out.print("The sum of " +x+ " and " +y+ " is " +s);
	}
	
	public static void sum (int x, int y, int z)
	{
		int s=x+y+z;
		System.out.print("\nThe sum of "+x+ ", " +y+ " and " +z+ " is " +s );
	}
	
	 public static float  sum(float x, float y)
		{   
			return x+y;
			
		}
	public static float  sum(float x, float y, float z)
		{   
			return x+y+z;
			
		}


	
	public static void main(String[] args) {

		Week2Main obj = new Week2Main("EFAJ");
        Week2Main obj1 = new Week2Main("EFAJ" ,"19-40338-1");
        Week2Main.sum(5, 7);
        Week2Main.sum(5, 7, 4);
       
            
		

	}

}
