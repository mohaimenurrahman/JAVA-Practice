package week4.exercises;

public class Box {

	private double length;
	private double width;
	private double height;
	
	public static double priceperunit=5.0;
	public static double totalprice=0.0;
	
	public void setLength(double l)
	{
		length =l;
	}
	
	public void setWidth(double w)
	{
		width =w;
	}
	
	public void setHeight(double h)
	{
		height =h;
	}
	
	public double getLength()
	{
		return length;
	}
	public double getWidth()
	{
		return width;
	}
	public double getHeight()
	{
		return height;
	}
	
	public double getPriceofBox()
	{
		double price;
		price=priceperunit*(length+width+length);
		totalprice=totalprice +price;
		return price;
	}
	


	}


