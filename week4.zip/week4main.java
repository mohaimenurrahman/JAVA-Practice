package week4.exercises;

public class week4main {

	public static void main(String[] args) {
			Box obj=new Box();
			obj.setLength(12.5);
			obj.setWidth(12.5);
			obj.setHeight(5.5);
		
			System.out.println("Length is :" +obj.getLength());
			System.out.println("Width is :" +obj.getWidth());
			System.out.println("Height is :" +obj.getHeight());
			System.out.println("Price of the box is :" +obj.getPriceofBox());
			System.out.println("Total price :" +Box.totalprice);
			
			 Box obj1= new Box();
			 obj1.setLength(5.5);
			 obj1.setHeight(12.5);
			 obj1.setWidth(12.5);
			 
			 System.out.print("\nLenght is: "+obj1.getLength());
			 System.out.print("\nWidth is: "+obj1.getWidth());
			 System.out.print("\nHeight is: "+obj1.getHeight());
			 System.out.print("\nPrice of this box is: "+obj1.getPriceofBox());
			 System.out.print("\nTotal price: "+obj1.totalprice);

			
			ScannerDemonstration obj2= new ScannerDemonstration();
			obj2.readDouble();
			obj2.readInteger();
			obj2.describeyourself();
			System.out.println(" ");

	}

}
