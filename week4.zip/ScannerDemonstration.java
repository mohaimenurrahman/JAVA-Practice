package week4.exercises;

import java.util.Scanner;

public class ScannerDemonstration {

	public static void readDouble()
	{
		Scanner s= new Scanner (System.in);
		System.out.print("\nlength is: ");
		double length = s.nextDouble();
		System.out.print("Width is:");
		double width = s.nextDouble();
		System.out.print("Height is:");
		double height = s.nextDouble();
		double area = length*width*height;
		System.out.println("Area is:"+(int)area);
		
	}
	
	public static void readInteger()
	{
		Scanner s =new Scanner (System.in);
		System.out.print("Enter 1st number:");
		int x=s.nextInt();
		System.out.print("Enter 2nd number:");
		int y=s.nextInt();
		int z=x+y;
		int p=x*y;
		System.out.println("sum:"+z+"\nproduct:" +p);
				

	}
	
	public void describeyourself()
	{
		Scanner s =new Scanner(System.in);
		String name,interest;
		int age;
		double height;
		System.out.print("Enter your name:");
		name=s.nextLine();
		System.out.print("Enter field of interest:");
		interest=s.nextLine();
		System.out.print("Enter your age:");
		age=s.nextInt();
		System.out.print("Enter your height:");
		height=s.nextDouble();
		System.out.println("Hey....my name is "+name+". I am "+age+" years of old. I am "+height+" feet long. Field of interest "+interest);
		
		
	}
	

}
