package labtask8;

public class Dog extends Animal{
	
	@Override
	public void animalsound()
	{
		System.out.println("vaw");
	}


}
