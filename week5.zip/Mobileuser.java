package labtask8;

public abstract class Mobileuser {
	
	public abstract void callingby();
	public abstract void msgfrom();

	

}
