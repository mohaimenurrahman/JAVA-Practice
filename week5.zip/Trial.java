package labtask8;
import java.util.Scanner;
public class Trial {

	
	
	    public static void exercise(){
	        int x=0;
	        do{
	            try{
	                Scanner input = new Scanner(System.in);
	                System.out.print("Enter First Number: ");
	                int num1 = input.nextInt();
	                System.out.print("Enter Seccond Number: ");
	                int num2 = input.nextInt();
	                System.out.println("Result: "+num1+"/"+num2+" = "+num1/num2);
	                x =1;
	            }
	            catch(Exception e){
	                System.out.println("Exception occured: "+e);
	            }
	           finally{
	                if(x==1){
	                    System.out.println("Task Completed Successfully.Thank you");
	                }
	                else{
	                    System.out.println("Enter number again");
	                }
	            } 
	        }
	        while(x==0);
	    }
}

	 


