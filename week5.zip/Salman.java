package labtask8;

public class Salman extends Mobileuser{
	
	@Override
	public void callingby()
	{
		System.out.println("calling by Salman");
	}
	
	@Override
	public void msgfrom()
	{
		System.out.println("msg:Hi its Salman");
	}

	

}
