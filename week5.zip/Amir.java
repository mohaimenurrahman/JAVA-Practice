package labtask8;

public class Amir extends Mobileuser{
	
	@Override
	public void callingby()
	{
		System.out.println("calling by Amir");
	}
	
	@Override
	public void msgfrom()
	{
		System.out.println("msg:Hi its Amir");
	}

	

}
