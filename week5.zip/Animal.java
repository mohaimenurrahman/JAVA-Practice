package labtask8;

public abstract class Animal {
	
	public abstract void animalsound();

	
}
