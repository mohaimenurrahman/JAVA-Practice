package labtask8;

public class Main {

	public static void main(String[] args) {
		
		
		Trial t=new Trial();
		t.exercise();
		
		Animal obj=new Cat();
		obj.animalsound();
		Animal obj1=new Dog();
		obj1.animalsound();
		
		Mobileuser obj2=new Salman();
		obj2.callingby();
		obj2.msgfrom();

		Mobileuser obj3=new Amir();
		obj3.callingby();
		obj3.msgfrom();
	}

}
