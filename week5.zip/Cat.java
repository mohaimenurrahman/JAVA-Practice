package labtask8;

public class Cat extends Animal {

	@Override
	public void animalsound()
	{
		System.out.println("mew");
	}

}
