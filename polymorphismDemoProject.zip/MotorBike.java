package polymorphismDemoProject;

public class MotorBike {

	public static void bike(String n)
	{
		System.out.println(n+"starting ....");
	}
	
	public static void bike()
	{
		System.out.println("Self starting ....");
	}

}
