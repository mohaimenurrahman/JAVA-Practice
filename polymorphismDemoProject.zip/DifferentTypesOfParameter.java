package polymorphismDemoProject;

public class DifferentTypesOfParameter {
	
	public void display(int i)
	{
		System.out.println("value of display int="+i);
	}

	public void display(double d)
	{
		System.out.println("value of display double="+d);
	}
	
	public void display(boolean bo)
	{
		System.out.println("value of display boolean="+bo);
	}
	
	public void display(char c)
	{
		System.out.println("value of display char="+c);
	}
	
	public void display(String msg)
	{
		System.out.println("value of display string="+msg);
	}
}
