package polymorphismDemoProject;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		System.out.println("********* Main Menu Choose numbers accordingly to show the Tasks ********************");
		System.out.println("Task 1\n");
		System.out.println("Task 2\n");
		System.out.println("Task 3\n");
		System.out.println("Task 4\n");
		System.out.println("Task 5\n");
		System.out.println("Task 6\n");
		
		int choice;
		System.out.println("Enter your choice:");
		Scanner sc = new Scanner(System.in);
		choice = sc.nextInt();
		switch (choice)
		{
			case 1:
			{
				task1();
				break;
			}
			
			case 2:
			{
				task2();
				break;
			}
			
			case 3:
			{
				task3();
				break;
			}
			
			case 4:
			{
				task4();
				break;
			}
			
			
			case 5:
			{
				task5();
				break;
			}
			
			case 6:
			{
				task6();
				break;
			}
			
		default:
			System.out.println("Invalid Choice");
		}
	}
		
		public static void task1()
		{
			System.out.println("************************ This is Task 1 result ******************** ");
			DifferentTypesOfParameter d =new DifferentTypesOfParameter();
			d.display(4.0);
			d.display(true);
			d.display('c');
			d.display("mohaimenur");
		}
		
		public static void task2()
		{
			System.out.println("************************ This is Task 2 result ******************** ");
			DifferentNumberOfParameter dn = new DifferentNumberOfParameter();
			dn.add(1);
			dn.add(1,2);
			dn.add(1,2,3);
			dn.add(1,2,3,4,5);
		}
		
		public static void task3()
		{
			System.out.println("************************ This is Task 3 result ******************** ");
			
			DifferentSequenceOfParameters ds = new DifferentSequenceOfParameters();
			ds.method(111,"efaj");
			ds.method("efaj",112);
			
			
		}
		
		public static void task4()
		{
			System.out.println("************************ This is Task 4 result ******************** ");
			Methodoverloading mol=new Methodoverloading();
			mol.add(5,5.0,5.0f);
		}
		
		public static void task5()
		{
			System.out.println("************************ This is Task 5 result ******************** ");
			 MotorBike mb=new  MotorBike();
			 mb.bike("kick ");
			 mb.bike();
		}
		
		public static void task6()
		{
			System.out.println("************************ This is Task 6 result ******************** ");
			DifferentSequenceOfParameters2 obj = new DifferentSequenceOfParameters2(111,"efaj");
			DifferentSequenceOfParameters2 obj1=new DifferentSequenceOfParameters2("efaj",112);
			
		}

	}


