package polymorphismDemoProject;

public class Methodoverloading {

	public static void add(int a ,double b, float c)
	{
		System.out.println("The sum of   (add(5, 5)) + add(5.0,5.0, 5.0) +add(5.0f, 5.f) is "+((a+a)+(b+b+b)+(c+c)));

	}
	

}
