package polymorphismDemoProject;

public class DifferentSequenceOfParameters2 {

	DifferentSequenceOfParameters2(int id , String name)
	{
		System.out.println("I�m the first definition of method dispid= "+id+"name = "+name);
	}
	
	DifferentSequenceOfParameters2(String name, int id)
	{
		System.out.println("I�m the second definition of method dispname= "+name+"id= " +id);
	}

	}


