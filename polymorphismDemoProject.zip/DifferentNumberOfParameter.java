package polymorphismDemoProject;

public class DifferentNumberOfParameter {

	public static void add(int a)
	{
		System.out.println("value of add(int a) method="+(a+a));

	}
	
	public static void add(int a , int b)
	{
		System.out.println("value of add(int a and b) method="+(a+b));

	}
	
	public static void add(int a ,int b, int c)
	{
		System.out.println("value of add(int a and b and c) method="+(a+b+c));

	}
	
	public static void add(int a, int b, int c, int d, int e)
	{
		System.out.println("value of add(int a and b and c and d and e) method="+(a+b+c+d+e));

	}

}
