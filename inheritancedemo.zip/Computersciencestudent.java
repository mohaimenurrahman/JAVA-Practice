package inheritancedemo;

public class Computersciencestudent extends Student {
    
	String major="CSE";
	@Override
	public void describeStudent()
	{
		super.describeStudent();
		System.out.println("My department is " +major);
	}
	

}
