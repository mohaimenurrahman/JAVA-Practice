package inheritancedemo;

public class Animal {
	public Animal()
	{
		System.out.println("Animal constructor");
	}

	public void animalSound()
	{
		System.out.println("The animal makes a sound");
	}

}
