package inheritancedemo;

public class Person {

	String name="Asik";
	int age=20;
	public void discribePerson()
	{
		System.out.println("My name is "+name+" i am "+age+ "years old. this is from person class");
	}
	public void displayDailyActivity()
	{
		System.out.println("wokes up, takes breakfast, does exercise, sleeps. This is from  Person class");
		
	}
	


}
