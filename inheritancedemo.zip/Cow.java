package inheritancedemo;

public class Cow extends Animal{
	
	@Override 
	public void animalSound()
	{
		System.out.println("mooooou");
	}
}
