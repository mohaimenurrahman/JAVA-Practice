package inheritancedemo;

public class Cat extends Animal {
	
	@Override 
	public void animalSound()
	{
		System.out.println("meeeeew");
	}

	
}
