package inheritancedemo;

public class Test {

	public static void main(String[] args) {
		Person obj = new Person();
		obj.discribePerson();
		obj.displayDailyActivity();
		
		Student obj1 = new Student();
		obj1.displayDailyActivity();
		obj1.describeStudent();
		
		Computersciencestudent obj2 =new Computersciencestudent();
		obj2.describeStudent();
		
		Animal obj3=new Animal();
		obj3.animalSound();
		
		Cat obj4 = new Cat();
		obj4.animalSound();
		Cow obj5=new Cow();
		obj5.animalSound();
		
		Dog obj6=new Dog();
		obj6.animalSound();
		
		
	
		

	}

}
