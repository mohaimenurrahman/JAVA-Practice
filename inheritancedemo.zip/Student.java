package inheritancedemo;

public class Student extends Person {
	int id=111;
	double cgpa=3.60;
	@Override 
	public void displayDailyActivity()
	{
		System.out.println("As a student i need to do much more activities");
	}

	public void describeStudent()
	{
		this.discribePerson();
		System.out.println("My id is"+id+ " My cgpa is "+cgpa+ " ");
		this.displayDailyActivity();
	}

}
